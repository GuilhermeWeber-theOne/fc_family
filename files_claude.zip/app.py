import json
import io
from datetime import date

import pandas as pd
import streamlit as st

import db
import stats

st.set_page_config(page_title="FutMatch PS5", page_icon="⚽", layout="centered")
db.init_db()

st.title("⚽ FutMatch — Placar do Grupo (PS5)")

PAGES = ["Nova Partida", "Histórico", "Ranking", "Jogadores", "Clubes / Ligas"]
page = st.sidebar.radio("Navegação", PAGES)


# ---------------------------------------------------------------
# PÁGINA: JOGADORES
# ---------------------------------------------------------------
if page == "Jogadores":
    st.header("Jogadores")

    with st.form("add_player", clear_on_submit=True):
        name = st.text_input("Nome / apelido do jogador")
        submitted = st.form_submit_button("Adicionar")
        if submitted and name.strip():
            db.add_player(name)
            st.success(f"Jogador '{name}' adicionado.")

    players = db.list_players()
    if players:
        st.subheader("Jogadores cadastrados")
        for p in players:
            col1, col2 = st.columns([4, 1])
            col1.write(p["name"])
            if col2.button("Remover", key=f"del_player_{p['id']}"):
                db.delete_player(p["id"])
                st.rerun()
    else:
        st.info("Nenhum jogador cadastrado ainda.")


# ---------------------------------------------------------------
# PÁGINA: CLUBES / LIGAS
# ---------------------------------------------------------------
elif page == "Clubes / Ligas":
    st.header("Clubes e Ligas")
    st.caption(
        "Importe sua lista de clubes do FC 26 via CSV ou JSON. "
        "Formato CSV: colunas 'club' e 'league'. "
        "Formato JSON: lista de objetos {\"club\": ..., \"league\": ...}."
    )

    tab_import, tab_manual, tab_list = st.tabs(["Importar arquivo", "Adicionar manual", "Lista atual"])

    with tab_import:
        uploaded = st.file_uploader("Selecione um arquivo CSV ou JSON", type=["csv", "json"])
        if uploaded is not None:
            try:
                if uploaded.name.endswith(".csv"):
                    df = pd.read_csv(uploaded)
                    rows = df.rename(columns=str.lower).to_dict(orient="records")
                else:
                    rows = json.load(uploaded)
                rows = [{"club": r["club"], "league": r["league"]} for r in rows]
                st.write(f"{len(rows)} clubes encontrados no arquivo.")
                if st.button("Importar para o app"):
                    db.bulk_add_clubs(rows)
                    st.success("Clubes importados com sucesso!")
                    st.rerun()
            except Exception as e:
                st.error(f"Erro ao ler arquivo: {e}")

        st.divider()
        st.caption("Baixe um template para editar com a sua lista completa do FC 26:")
        template_csv = "club,league\nReal Madrid,La Liga\nManchester City,Premier League\nFlamengo,Brasileirão\n"
        st.download_button(
            "Baixar template CSV",
            data=template_csv,
            file_name="clubes_template.csv",
            mime="text/csv",
        )

    with tab_manual:
        with st.form("add_club", clear_on_submit=True):
            club_name = st.text_input("Nome do clube")
            league_name = st.text_input("Liga")
            submitted = st.form_submit_button("Adicionar clube")
            if submitted and club_name.strip() and league_name.strip():
                db.add_club(club_name, league_name)
                st.success(f"Clube '{club_name}' adicionado à liga '{league_name}'.")

    with tab_list:
        clubs = db.list_clubs()
        if clubs:
            st.dataframe(pd.DataFrame(clubs)[["name", "league"]].rename(
                columns={"name": "Clube", "league": "Liga"}), use_container_width=True, hide_index=True)
            if st.button("🗑️ Limpar todos os clubes"):
                db.clear_clubs()
                st.rerun()
        else:
            st.info("Nenhum clube cadastrado ainda. Importe um arquivo na aba ao lado.")


# ---------------------------------------------------------------
# PÁGINA: NOVA PARTIDA
# ---------------------------------------------------------------
elif page == "Nova Partida":
    st.header("Registrar nova partida")

    players = db.list_players()
    clubs = db.list_clubs()

    if not players:
        st.warning("Cadastre pelo menos um jogador antes de registrar uma partida.")
        st.stop()
    if not clubs:
        st.warning("Cadastre ou importe clubes antes de registrar uma partida.")
        st.stop()

    player_names = {p["id"]: p["name"] for p in players}
    club_labels = {c["id"]: f"{c['name']} ({c['league']})" for c in clubs}

    match_date = st.date_input("Data da partida", value=date.today())
    note = st.text_input("Observação (opcional)", placeholder="Ex: Torneio da noite, ida/volta, etc.")

    st.subheader("Lado Casa")
    n_casa = st.number_input("Quantos jogadores no lado Casa?", min_value=1, max_value=4, value=1, key="n_casa")
    casa_entries = []
    for i in range(int(n_casa)):
        c1, c2, c3 = st.columns([2, 2, 1])
        pid = c1.selectbox(f"Jogador (Casa #{i+1})", options=list(player_names.keys()),
                            format_func=lambda x: player_names[x], key=f"casa_p_{i}")
        cid = c2.selectbox(f"Clube (Casa #{i+1})", options=list(club_labels.keys()),
                            format_func=lambda x: club_labels[x], key=f"casa_c_{i}")
        gols = c3.number_input("Gols", min_value=0, value=0, key=f"casa_g_{i}")
        casa_entries.append({"player_id": pid, "club_id": cid, "side": "casa", "goals": gols})

    st.subheader("Lado Fora")
    n_fora = st.number_input("Quantos jogadores no lado Fora?", min_value=1, max_value=4, value=1, key="n_fora")
    fora_entries = []
    for i in range(int(n_fora)):
        c1, c2, c3 = st.columns([2, 2, 1])
        pid = c1.selectbox(f"Jogador (Fora #{i+1})", options=list(player_names.keys()),
                            format_func=lambda x: player_names[x], key=f"fora_p_{i}")
        cid = c2.selectbox(f"Clube (Fora #{i+1})", options=list(club_labels.keys()),
                            format_func=lambda x: club_labels[x], key=f"fora_c_{i}")
        gols = c3.number_input("Gols", min_value=0, value=0, key=f"fora_g_{i}")
        fora_entries.append({"player_id": pid, "club_id": cid, "side": "fora", "goals": gols})

    all_entries = casa_entries + fora_entries
    label, winner, totals = stats.match_result_label(all_entries)
    st.info(f"Placar atual: **{label}**")

    if st.button("💾 Salvar partida", type="primary"):
        used_players = [e["player_id"] for e in all_entries]
        if len(used_players) != len(set(used_players)):
            st.error("Um mesmo jogador não pode aparecer duas vezes na mesma partida.")
        else:
            db.create_match(match_date.isoformat(), note, all_entries)
            st.success("Partida salva com sucesso!")
            st.rerun()


# ---------------------------------------------------------------
# PÁGINA: HISTÓRICO
# ---------------------------------------------------------------
elif page == "Histórico":
    st.header("Histórico de partidas")
    matches = db.list_matches()

    if not matches:
        st.info("Nenhuma partida registrada ainda.")
    else:
        for m in matches:
            label, winner, totals = stats.match_result_label(m["entries"])
            with st.expander(f"📅 {m['match_date']} — {label}" + (f" ({m['note']})" if m["note"] else "")):
                casa = [e for e in m["entries"] if e["side"] == "casa"]
                fora = [e for e in m["entries"] if e["side"] == "fora"]
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("**Casa**")
                    for e in casa:
                        st.write(f"{e['player_name']} — {e['club_name']} — {e['goals']} gol(s)")
                with col2:
                    st.markdown("**Fora**")
                    for e in fora:
                        st.write(f"{e['player_name']} — {e['club_name']} — {e['goals']} gol(s)")
                if st.button("🗑️ Excluir partida", key=f"del_match_{m['id']}"):
                    db.delete_match(m["id"])
                    st.rerun()


# ---------------------------------------------------------------
# PÁGINA: RANKING
# ---------------------------------------------------------------
elif page == "Ranking":
    st.header("🏆 Classificação do grupo")
    st.caption("Atualizada em tempo real, por pontos corridos (V=3 · E=1 · D=0).")

    players = db.list_players()
    matches = db.list_matches()

    if not players:
        st.info("Cadastre jogadores para gerar a tabela de classificação.")
    else:
        ranking = stats.build_ranking(players, matches)
        df = pd.DataFrame(ranking)

        def highlight_leader(row):
            if row["Pos"] == 1 and row["J"] > 0:
                return ["background-color: #fff3b0"] * len(row)
            return [""] * len(row)

        st.dataframe(
            df.style.apply(highlight_leader, axis=1),
            use_container_width=True,
            hide_index=True,
            column_config={
                "Pos": st.column_config.NumberColumn("Pos", width="small"),
                "Pts": st.column_config.NumberColumn("Pts", width="small"),
            },
        )
        st.caption(
            "J = Jogos · V = Vitórias · E = Empates · D = Derrotas · "
            "GM = Gols Marcados · GS = Gols Sofridos · SG = Saldo de Gols · "
            "Pts = Pontos.  Desempate: Pts → V → SG → GM → nome (A-Z)."
        )
